package com.example.futuredictionary

class CollegeSearch {
    var Name: String? = null
    var Code: String? = null
    var Affliatedby: String? = null
    var Phoneno: String? = null

    constructor(Name: String, Code: String, Affliatedby: String, Phoneno: String) {
        this.Name = Name
        this.Code = Code
        this.Affliatedby = Affliatedby
        this.Phoneno = Phoneno
    }

}