package com.example.futuredictionary

data class CollegesDataClass(val Name : String, val Code : String, val Affliatedby : String, val Phoneno : String)