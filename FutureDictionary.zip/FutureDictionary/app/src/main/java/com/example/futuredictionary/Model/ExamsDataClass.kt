package com.example.futuredictionary

data class ExamsDataClass(val Title : String, val Description : String)